package com.example.myscientificcalci;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    Button b1, b2, b3, b4, b5, b6, b7, b8, b9, b0, bdot, bpi, bequal, bplus, bmin, bmul, bdiv, binv, bsqrt, bsquare, bfact, bln, blog, btan, bcos, bsin, bb1, bb2, bc, bac, be;
    TextView tvmain, tvsec;
    String pi = "3.14159265";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Initialize buttons and text views
        initializeViews();

        // Set OnClickListeners for buttons
        setOnClickListeners();
    }

    private void initializeViews() {
        b1 = findViewById(R.id.b1);
        b2 = findViewById(R.id.b2);
        b3 = findViewById(R.id.b3);
        b4 = findViewById(R.id.b4);
        b5 = findViewById(R.id.b5);
        b6 = findViewById(R.id.b6);
        b7 = findViewById(R.id.b7);
        b8 = findViewById(R.id.b8);
        b9 = findViewById(R.id.b9);
        b0 = findViewById(R.id.b0);
        bpi = findViewById(R.id.bpi);
        bdot = findViewById(R.id.bdot);
        bequal = findViewById(R.id.bequal);
        bplus = findViewById(R.id.bplus);
        bmin = findViewById(R.id.bmin);
        bmul = findViewById(R.id.bmul);
        bdiv = findViewById(R.id.bdiv);
        binv = findViewById(R.id.binv);
        bsqrt = findViewById(R.id.bsqrt);
        bsquare = findViewById(R.id.bsquare);
        bfact = findViewById(R.id.bfact);
        bln = findViewById(R.id.bln);
        blog = findViewById(R.id.blog);
        btan = findViewById(R.id.btan);
        bsin = findViewById(R.id.bsin);
        bcos = findViewById(R.id.bcos);
        bb1 = findViewById(R.id.bb1);
        bb2 = findViewById(R.id.bb2);
        bc = findViewById(R.id.bc);
        bac = findViewById(R.id.bac);
        be = findViewById(R.id.be);

        tvmain = findViewById(R.id.tvmain);
        tvsec = findViewById(R.id.tvsec);
    }

    private void setOnClickListeners() {
        b1.setOnClickListener(v -> tvmain.append("1"));
        b2.setOnClickListener(v -> tvmain.append("2"));
        b3.setOnClickListener(v -> tvmain.append("3"));
        b4.setOnClickListener(v -> tvmain.append("4"));
        b5.setOnClickListener(v -> tvmain.append("5"));
        b6.setOnClickListener(v -> tvmain.append("6"));
        b7.setOnClickListener(v -> tvmain.append("7"));
        b8.setOnClickListener(v -> tvmain.append("8"));
        b9.setOnClickListener(v -> tvmain.append("9"));
        b0.setOnClickListener(v -> tvmain.append("0"));
        bdot.setOnClickListener(v -> tvmain.append("."));
        bac.setOnClickListener(v -> {
            tvmain.setText("");
            tvsec.setText("");
        });
        bc.setOnClickListener(v -> {
            String val = tvmain.getText().toString();
            if (val.length() > 0) {
                tvmain.setText(val.substring(0, val.length() - 1));
            }
        });
        bplus.setOnClickListener(v -> tvmain.append("+"));
        bmin.setOnClickListener(v -> tvmain.append("-"));
        bmul.setOnClickListener(v -> tvmain.append("×"));
        bdiv.setOnClickListener(v -> tvmain.append("÷"));
        bsqrt.setOnClickListener(v -> calculateSquareRoot());
        bb1.setOnClickListener(v -> tvmain.append("("));
        bb2.setOnClickListener(v -> tvmain.append(")"));
        bpi.setOnClickListener(v -> {
            tvsec.setText(bpi.getText());
            tvmain.append(pi);
        });
        bsin.setOnClickListener(v -> tvmain.append("sin"));
        bcos.setOnClickListener(v -> tvmain.append("cos"));
        btan.setOnClickListener(v -> tvmain.append("tan"));
        binv.setOnClickListener(v -> tvmain.append("^(-1)"));
        bfact.setOnClickListener(v -> calculateFactorial());
        bsquare.setOnClickListener(v -> calculateSquare());
        bln.setOnClickListener(v -> tvmain.append("ln"));
        blog.setOnClickListener(v -> tvmain.append("log"));
        be.setOnClickListener(v -> calculateExponential());

        bequal.setOnClickListener(v -> calculateResult());
    }

    private void calculateSquareRoot() {
        String val = tvmain.getText().toString();
        if (!val.isEmpty()) {
            double r = Math.sqrt(Double.parseDouble(val));
            tvmain.setText(String.valueOf(r));
        }
    }

    private void calculateFactorial() {
        String val = tvmain.getText().toString();
        if (!val.isEmpty()) {
            int intVal = Integer.parseInt(val);
            int fact = factorial(intVal);
            tvmain.setText(String.valueOf(fact));
            tvsec.setText(intVal + "!");
        }
    }

    private void calculateSquare() {
        String val = tvmain.getText().toString();
        if (!val.isEmpty()) {
            double d = Double.parseDouble(val);
            double square = d * d;
            tvmain.setText(String.valueOf(square));
            tvsec.setText(d + "²");
        }
    }
    private void calculateExponential() {
        String val = tvmain.getText().toString();
        try {
            double base = Double.parseDouble(val);
            double result = Math.exp(base);
            tvmain.setText(String.valueOf(result));
            tvsec.setText("e^" + val);
        } catch (NumberFormatException e) {
            tvmain.setText("Error");
        }
    }


    private void calculateResult() {
        String val = tvmain.getText().toString();
        if (!val.isEmpty()) {
            String replacedStr = val.replace('÷', '/').replace('×', '*');
            try {
                double result = eval(replacedStr);
                tvmain.setText(String.valueOf(result));
                tvsec.setText(val);
            } catch (Exception e) {
                tvmain.setText("Error");
            }
        }
    }

    // Factorial function
    int factorial(int n) {
        return (n == 1 || n == 0) ? 1 : n * factorial(n - 1);
    }

    // Eval function
    public static double eval(final String str) {
        return new Object() {
            int pos = -1, ch;

            void nextChar() {
                ch = (++pos < str.length()) ? str.charAt(pos) : -1;
            }

            boolean eat(int charToEat) {
                while (ch == ' ') nextChar();
                if (ch == charToEat) {
                    nextChar();
                    return true;
                }
                return false;
            }

            double parse() {
                nextChar();
                double x = parseExpression();
                if (pos < str.length()) throw new RuntimeException("Unexpected: " + (char) ch);
                return x;
            }

            double parseExpression() {
                double x = parseTerm();
                for (; ; ) {
                    if (eat('+')) x += parseTerm(); // addition
                    else if (eat('-')) x -= parseTerm(); // subtraction
                    else return x;
                }
            }

            double parseTerm() {
                double x = parseFactor();
                for (; ; ) {
                    if (eat('*')) x *= parseFactor(); // multiplication
                    else if (eat('/')) x /= parseFactor(); // division
                    else return x;
                }
            }

            double parseFactor() {
                if (eat('+')) return parseFactor(); // unary plus
                if (eat('-')) return -parseFactor(); // unary minus

                double x;
                int startPos = this.pos;
                if (eat('(')) { // parentheses
                    x = parseExpression();
                    eat(')');
                } else if ((ch >= '0' && ch <= '9') || ch == '.') { // numbers
                    while ((ch >= '0' && ch <= '9') || ch == '.') nextChar();
                    x = Double.parseDouble(str.substring(startPos, this.pos));
                } else if (ch >= 'a' && ch <= 'z') { // functions
                    while (ch >= 'a' && ch <= 'z') nextChar();
                    String func = str.substring(startPos, this.pos);
                    x = parseFactor();
                    if (func.equals("sqrt")) x = Math.sqrt(x);
                    else if (func.equals("ex^")) x = Math.exp(x);
                    else if (func.equals("sin")) x = Math.sin(Math.toRadians(x));
                    else if (func.equals("cos")) x = Math.cos(Math.toRadians(x));
                    else if (func.equals("tan")) x = Math.tan(Math.toRadians(x));
                    else if (func.equals("log")) x = Math.log10(x);
                    else if (func.equals("ln")) x = Math.log(x);

                    else throw new RuntimeException("Unknown function: " + func);
                } else {
                    throw new RuntimeException("Unexpected: " + (char) ch);
                }

                if (eat('^')) x = Math.pow(x, parseFactor()); // exponentiation

                return x;
            }
        }.parse();
    }
}
