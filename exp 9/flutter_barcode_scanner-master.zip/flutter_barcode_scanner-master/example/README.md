# flutter_barcode_scanner_example

Demonstrates how to use the flutter_barcode_scanner plugin.
