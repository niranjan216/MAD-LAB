package com.amolg.flutterbarcodescannerexample;

import io.flutter.embedding.android.FlutterActivity;

public class MainActivity extends FlutterActivity {
  // You can keep this empty class or remove it. Plugins on the new embedding
  // now automatically registers plugins.
}