#import <Flutter/Flutter.h>

@interface FlutterBarcodeScannerPlugin : NSObject<FlutterPlugin>
@end
